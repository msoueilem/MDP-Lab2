DemoAppHello compressed file is the in class demonstrated example
Lesson3 compressed file is the BirthdayWishApp

Extract both files on your PC. Then Open Andriod Studio, 
Click File-> New->Import Project one by one.

