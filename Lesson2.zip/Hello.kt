package lesson2

fun main(args: Array<String>) {
    println("Hello World")
}