package com.example.kotlinfundamendals.interfacedemo

class InterfaceImp : MyInterface {

    override val test: Int = 25
    override fun print() = "Kotlin"

}