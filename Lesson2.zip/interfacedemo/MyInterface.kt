package com.example.kotlinfundamendals.interfacedemo

interface MyInterface {

    val test: Int

    // Abstract method
    fun print() : String

    // default implementation
    fun hello(name: String) {
        println("Hello there, $name!")
    }
}
