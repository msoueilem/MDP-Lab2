package com.example.kotlinfundamendals

data class Person (val fname:String, val lname:String, var age:Int){
}
