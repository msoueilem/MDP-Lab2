package com.miu.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.app.PendingIntent
import android.graphics.BitmapFactory
import android.os.Build
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    // Need to initialize the following fields
    lateinit var notificationManager: NotificationManager
    lateinit var notificationChannel: NotificationChannel
    lateinit var builder: Notification.Builder
    private val channelId = "com.miu.myapplication" // Package Name
    private val description = "Test Notification"// Text message appear on notification
    lateinit var pendingIntent: PendingIntent
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // get the notification servive from system service and assign to notificationManager
        notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        button.setOnClickListener {
            // You execute the notification based on min andriod sdk version
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                // Creating an Intent to pointing your activity
                val intent = Intent(this, LauncherActivity::class.java)
                pendingIntent =
                    PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)

                // Do the following steps to prepare the notification channel
                notificationChannel =
                    NotificationChannel(channelId, description, NotificationManager.IMPORTANCE_HIGH)
                notificationChannel.enableLights(true)
                notificationChannel.lightColor = Color.GREEN
                notificationChannel.enableVibration(false)
                // Set the notificationChannel to NotificationManager instance
                notificationManager.createNotificationChannel(notificationChannel)
                //Build Notification by doing the following steps
                builder = Notification.Builder(this, channelId)
                    .setContentTitle("My Notification")
                    .setContentText("Sample Notification Test for Android")
                    .setSmallIcon(R.drawable.search_logo)
                    .setLargeIcon(
                        BitmapFactory.decodeResource(
                            this.resources,
                            R.drawable.twitter_logo
                        )
                    )
                    .setContentIntent(pendingIntent)
            } else {
                builder = Notification.Builder(this)
                    .setContentTitle("My Notification")
                    .setContentText("Sample Notification Test for Android")
                    .setSmallIcon(R.drawable.search_logo)
                    .setLargeIcon(
                        BitmapFactory.decodeResource(
                            this.resources,
                            R.drawable.twitter_logo
                        )
                    )
                    .setContentIntent(pendingIntent)
            }
        }
    }
}
